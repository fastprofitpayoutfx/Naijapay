#!/bin/bash
# Flutter Project Setup Script

echo "Setting up NaijaPay Flutter Project..."

# Check if Flutter is installed
if ! command -v flutter &> /dev/null; then
    echo "Flutter is not installed. Please install Flutter first."
    echo "Visit: https://docs.flutter.dev/get-started/install"
    exit 1
fi

# Get Flutter dependencies
echo "Installing dependencies..."
flutter pub get

# Create necessary directories if not exist
mkdir -p android/app/src/main/res/drawable
mkdir -p ios/Runner

# Check for .env file
if [ ! -f .env ]; then
    echo "Creating .env file..."
    echo "# Environment variables for NaijaPay app" > .env
    echo "API_URL=https://api.naijapay.example.com" >> .env
    echo "API_KEY=your_api_key_here" >> .env
    echo ".env file created. Please update with your actual API keys."
fi

# Offering to run Flutter doctor
echo "Would you like to run Flutter doctor to verify setup? (y/n)"
read answer
if [ "$answer" == "y" ]; then
    flutter doctor
fi

echo "Setup complete! You can now run 'flutter run' to start the app."